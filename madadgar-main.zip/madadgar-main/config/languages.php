<?php
return [
    'ur' => 'Urdu',
    'en' => 'English'


];
