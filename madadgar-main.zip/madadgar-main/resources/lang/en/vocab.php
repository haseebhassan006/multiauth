<?php



return [

	'home' => 'Home',
	'about' => 'About',
	'contact' => 'Contact Us',
	'login' =>'Login',
	'urgent_donation' => 'Ugent Donations',
	'mosque_request' =>'Mosque Request',
	'login_as_donator' => 'Login As Donator',
	'login_as_serviceprovider' => 'Login As Service Provider',
	'login_as_imam_masjid' => 'Login As Imam',
    'create_request' => 'Create Request',
];
?>
