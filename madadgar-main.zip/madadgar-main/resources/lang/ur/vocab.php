<?php

return [
    'home' => 'صفحہ اول',
    'about'=>'تعارف',
    'mosque_request'=>'مسجد کی درخواست',
    'urgent_donation' => 'فوری عطیات',
    'contact' => 'رابطہ',
    'login'=>'لاگن کریں',
    'login_as_donator' => 'بطور ڈونیٹر',
    'login_as_serviceprovider' => 'بطور سروس پروائیڈر',
    'login_as_imam_masjid' => 'بطورامام',
    'create_request' => "درخواست بنائیں",

];
