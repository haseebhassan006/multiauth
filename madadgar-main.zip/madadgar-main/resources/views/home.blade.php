@extends('layouts.app')

@section('content')

@component('layouts.components.slider')
@endcomponent
@component('layouts.components.about')
@endcomponent
@component('layouts.components.urgentdonation')
@endcomponent
@component('layouts.components.requests')
@endcomponent


@endsection
