@extends('admin.layouts.template')

@section('content')
@endsection