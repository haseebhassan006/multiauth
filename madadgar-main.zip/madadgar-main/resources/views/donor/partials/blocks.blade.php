<div class="main-page second py-5">
<div class="container">
<div class="row">
<div class="col-md-12 mb-3">
<h2 class="pull-left m-0 p-0">Revenue Earned</h2>
<p class="pull-right mb-0 mt-1 p-0">
Available For Withdrawal: <span class="font-weight-bold text-success"> $5.00 </span>
</p>
</div>
<div class="col-md-12">
<div class="mb-3 border-0 bg-white shadow-sm rounded ">
<div class="card-body">
<div class="row">
<div class="col-md-3 text-center border-box">
<p> Withdrawals </p>
<h1 class="font-weight-bold m-0">$12,000</h1>
</div>
<div class="col-md-3 text-center border-box">
<p> Used To Order Proposals/Services </p>
<h1 class="font-weight-bold m-0">$1,00.50</h1>
</div>
<div class="col-md-3 text-center border-box">
<p> Pending Clearance </p>
<h1 class="font-weight-bold m-0">$-1015.00</h1>
</div>
<div class="col-md-3 text-center border-box">
<p> Available Income </p>
<h1 class="font-weight-bold m-0">$5.00</h1>
</div>
</div>
</div>
</div>