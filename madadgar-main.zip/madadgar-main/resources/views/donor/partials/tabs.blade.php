<p class="pull-left my-2 mr-2"> Withdraw To: </p>
<button class="btn btn-success ml-2">
<i class="fa fa-paypal"></i> Paypal Account
</button>
<button class="btn btn-outline-success ml-2">
<i class="fa fa-university"></i> Bank Account
</button>
<button class="btn btn-outline-success ml-2">
<i class="fa fa-credit-card"></i> Moneygram
</button>
<button class="btn btn-outline-success ml-2">
<i class="fa fa-bitcoin"></i> Bitcoin Wallet
</button>