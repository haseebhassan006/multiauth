<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="Gurdeep singh osahan">
<meta name="author" content="Gurdeep singh osahan">
<title>Donor</title>

<link rel="icon" type="image/png" href="images/fav.svg">


<link href="{{asset('assets/donor/vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">

<link href="{{asset('assets/donor/vendor/fontawesome/css/font-awesome.min.css')}}" rel="stylesheet">

<link href="{{asset('assets/donor/vendor/icons/css/materialdesignicons.min.css')}}" media="all" rel="stylesheet" type="text/css">

<link href="{{asset('assets/donor/vendor/slick-master/slick/slick.css')}}" rel="stylesheet" type="text/css">

<link href="{{asset('assets/donor/vendor/lightgallery-master/dist/css/lightgallery.min.css')}}" rel="stylesheet">

<link href="{{asset('assets/donor/vendor/select2/css/select2-bootstrap.css')}}">
<link href="{{asset('assets/donor/vendor/select2/css/select2.min.css')}}" rel="stylesheet">

<link href="{{asset('assets/donor/css/style.css')}}" rel="stylesheet">
<link href="{{asset('css/app.css')}}"
</head>