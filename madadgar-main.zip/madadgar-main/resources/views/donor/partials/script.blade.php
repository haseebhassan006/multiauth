    <script src="{{asset('frontend/assets/js/jquery.min.js')}}"></script>
        <script src="{{asset('frontend/assets/js/popper.min.js')}}"></script>
<script src="{{asset('assets/donor/vendor/bootstrap/js/bootstrap.bundle.min.js')}}" type="70d849704b910ddfc82e19d9-text/javascript"></script>


<script src="{{asset('assets/donor/js/jqBootstrapValidation.js')}}" type="70d849704b910ddfc82e19d9-text/javascript"></script>
<script src="{{asset('assets/donor/js/contact_me.js')}}" type="70d849704b910ddfc82e19d9-text/javascript"></script>

<script src="{{asset('assets/donor/vendor/slick-master/slick/slick.js')}}" type="70d849704b910ddfc82e19d9-text/javascript" charset="utf-8"></script>

<script src="{{asset('assets/donor/vendor/lightgallery-master/dist/js/lightgallery-all.min.js')}}" type="70d849704b910ddfc82e19d9-text/javascript"></script>

<script src="{{asset('assets/donor/vendor/select2/js/select2.min.js')}}" type="70d849704b910ddfc82e19d9-text/javascript"></script>

<script src="{{asset('assets/donor/js/custom.js')}}" type="70d849704b910ddfc82e19d9-text/javascript"></script>
<script src="../../cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="70d849704b910ddfc82e19d9-|49" defer=""></script>
<script defer="" src="../../beacon.min.js" data-cf-beacon='{"rayId":"6548b66afc6bfa98","version":"2021.5.1","r":1,"token":"dd471ab1978346bbb991feaa79e6ce5c","si":10}'></script>
<script type="text/javascript" src="{{asset('js/app.js')}}"></script>