
<!DOCTYPE html>
<html>
@include('donor.partials.head')
<body>

@include('donor.partials.header')

@yield('content')
@include('donor.partials.footer')

@include('donor.partials.script')
</body>
</html>