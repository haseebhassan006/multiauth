<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="" />
        <meta name="keywords" content="" />
        <link rel="icon" href="{{asset('frontend/assets/images/favicon.png')}}" sizes="35x35" type="image/png">
        <title>Maktab - The Islamic Center HTML5 Template</title>

        <link rel="stylesheet" href="{{asset('frontend/assets/css/all.min.css')}}">
        <link rel="stylesheet" href="{{asset('frontend/assets/css/flaticon.css')}}">
        <link rel="stylesheet" href="{{asset('frontend/assets/css/animate.min.css')}}">
        <link rel="stylesheet" href="{{asset('frontend/assets/css/bootstrap.min.css')}}">
        <link rel="stylesheet" href="{{asset('frontend/assets/css/jquery.fancybox.min.css')}}">
        <link rel="stylesheet" href="{{asset('frontend/assets/css/jquery.bootstrap-touchspin.min.css')}}">
        <link rel="stylesheet" href="{{asset('frontend/assets/css/perfect-scrollbar.css')}}">
        <link rel="stylesheet" href="{{asset('frontend/assets/css/slick.css')}}">
        <link rel="stylesheet" href="{{asset('frontend/assets/css/style.css')}}">
        <link rel="stylesheet" href="{{asset('frontend/assets/css/responsive.css')}}">
        <link rel="stylesheet" href="{{asset('frontend/assets/css/color.css')}}">
    </head>