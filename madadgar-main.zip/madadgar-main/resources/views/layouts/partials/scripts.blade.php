
        <script src="{{asset('frontend/assets/js/jquery.min.js')}}"></script>
        <script src="{{asset('frontend/assets/js/popper.min.js')}}"></script>
        <script src="{{asset('frontend/assets/js/bootstrap.min.js')}}"></script>
        <script src="{{asset('frontend/assets/js/wow.min.js')}}"></script>
        <script src="{{asset('frontend/assets/js/counterup.min.js')}}"></script>
        <script src="{{asset('frontend/assets/js/jquery.fancybox.min.js')}}"></script>
        <script src="{{asset('frontend/assets/js/jquery.bootstrap-touchspin.min.js')}}"></script>
        <script src="{{asset('frontend/assets/js/perfect-scrollbar.min.js')}}"></script>
        <script src="{{asset('frontend/assets/js/slick.min.js')}}"></script>
        <!-- <script src="assets/js/particles.min.js"></script>
        <script src="assets/js/particle-int.js"></script> -->
        <script src="{{asset('frontend/assets/js/musicplayer-min.js')}}"></script>
        <script src="{{asset('frontend/assets/js/custom-scripts.js')}}"></script>