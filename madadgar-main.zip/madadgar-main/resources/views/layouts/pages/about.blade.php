@extends('layouts.app')
@section('content')
@component('layouts.components.aboutComponent')
@endcomponent
@endsection