@extends('layouts.app')
@section('content')
@component('layouts.components.requests')
@endcomponent
@endsection