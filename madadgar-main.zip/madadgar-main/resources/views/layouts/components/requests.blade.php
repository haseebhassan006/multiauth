
            <section>
                <div class="w-100 pb-80 position-relative">
                    <div class="container">
                        <div class="sec-title text-center w-100">
                            <div class="sec-title-inner d-inline-block">
                                <i class="thm-clr flaticon-rub-el-hizb"></i>
                                <h2 class="mb-0">Services We Offer</h2>
                                <p class="mb-0">Adipiscing elit duis volutpat ligula nulla dapibus.</p>
                            </div>
                        </div><!-- Sec Title -->
                        <div class="serv-wrap wide-sec">
                            <div class="row mrg10 serv-caro">
                                <div class="col-md-4 col-sm-6 col-lg-3">
                                    <div class="serv-box text-center pat-bg gray-layer opc85 position-relative back-blend-multiply gray-bg w-100" style="background-image: url(assets/images/pattern-bg.jpg);">
                                        <i class="flaticon-mat thm-clr"></i>
                                        <h3 class="mb-0">Help Poor's</h3>
                                        <p class="mb-0">Lorem ipsum dolor sit amet, coteudtu adipisicing elit, sed do eiusmod tem por incididunt ut labore et.</p>
                                        <a href="services-detail.html" title="">Read More</a>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6 col-lg-3">
                                    <div class="serv-box text-center pat-bg gray-layer opc85 position-relative back-blend-multiply gray-bg w-100" style="background-image: url(assets/images/pattern-bg.jpg);">
                                        <i class="flaticon-minaret thm-clr"></i>
                                        <h3 class="mb-0">Mosque Development</h3>
                                        <p class="mb-0">Lorem ipsum dolor sit amet, coteudtu adipisicing elit, sed do eiusmod tem por incididunt ut labore et.</p>
                                        <a href="services-detail.html" title="">Read More</a>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6 col-lg-3">
                                    <div class="serv-box text-center pat-bg gray-layer opc85 position-relative back-blend-multiply gray-bg w-100" style="background-image: url(assets/images/pattern-bg.jpg);">
                                        <i class="flaticon-grave thm-clr"></i>
                                        <h3 class="mb-0">Funeral Service</h3>
                                        <p class="mb-0">Lorem ipsum dolor sit amet, coteudtu adipisicing elit, sed do eiusmod tem por incididunt ut labore et.</p>
                                        <a href="services-detail.html" title="">Read More</a>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6 col-lg-3">
                                    <div class="serv-box text-center pat-bg gray-layer opc85 position-relative back-blend-multiply gray-bg w-100" style="background-image: url(assets/images/pattern-bg.jpg);">
                                        <i class="flaticon-quran thm-clr"></i>
                                        <h3 class="mb-0">Quran Learning</h3>
                                        <p class="mb-0">Lorem ipsum dolor sit amet, coteudtu adipisicing elit, sed do eiusmod tem por incididunt ut labore et.</p>
                                        <a href="services-detail.html" title="">Read More</a>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6 col-lg-3">
                                    <div class="serv-box text-center pat-bg gray-layer opc85 position-relative back-blend-multiply gray-bg w-100" style="background-image: url(assets/images/pattern-bg.jpg);">
                                        <i class="flaticon-arabic thm-clr"></i>
                                        <h3 class="mb-0">Community Service</h3>
                                        <p class="mb-0">Lorem ipsum dolor sit amet, coteudtu adipisicing elit, sed do eiusmod tem por incididunt ut labore et.</p>
                                        <a href="services-detail.html" title="">Read More</a>
                                    </div>
                                </div>
                            </div>
                        </div><!-- Services Wrap -->
                    </div>
                </div>
            </section>