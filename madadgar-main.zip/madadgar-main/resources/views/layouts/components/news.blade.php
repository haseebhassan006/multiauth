<section>
                <div class="w-100 pt-90 pb-235 position-relative">
                    <img class="sec-botm-rgt-mckp img-fluid position-absolute" src="{{asset('frontend/assets/images/sec-botm-mckp.png')}}" alt="Sec Bottom Mockup">
                  
                </div>
            </section>