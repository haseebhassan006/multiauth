  
            <section>
                <div class="w-100 pt-220 pb-80 position-relative">
                    <img class="img-fluid sec-top-mckp position-absolute" src="{{asset('frontend/assets/images/sec-top-mckp.png')}}" alt="Sec Top Mockup">
                    <div class="container">
                        <div class="about-wrap text-center position-relative w-100">
                            <div class="about-inner d-inline-block">
                                <img class="img-fluid" src="{{asset('frontend/assets/images/bism-img1.png')}}" alt="Bismillah Image">
                                <h2 class="mb-0">Welcome To The Islam Home</h2>
                                <p class="mb-0">The is not just a mosque for prayers rather it is a community center for all. The Center is committed to preserving an Islamic identity, building and supporting a viable Muslim community, promoting a comprehensive Islamic way of life based on the Holy Quran and the Sunnah of Prophet Muhammad.</p>
                                <a class="thm-btn thm-bg" href="about.html" title="">Learn More<span></span><span></span><span></span><span></span></a>
                            </div>
                        </div><!-- About Wrap -->
                    </div>
                </div>
            </section>